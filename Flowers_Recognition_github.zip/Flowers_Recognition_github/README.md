# Flower Recognition Using Deep Learning and Transfer Learning

## MSc Artificial Intelligence Project

This project was developed as part of my MSc in Artificial Intelligence at the University of East London.

The project focuses on multiclass flower image classification using Deep Learning and Transfer Learning.

## Dataset

The project uses the Kaggle Flowers Recognition dataset.

The model classifies images into five categories:

* Daisy
* Dandelion
* Rose
* Sunflower
* Tulip

The experiments use a 70% training, 15% validation, and 15% testing split, with images resized to 224 × 224 pixels.

## Models

The project compares:

* Shallow CNN — baseline model
* ResNet18 — Transfer Learning
* DenseNet201 — Transfer Learning

The pretrained ResNet18 and DenseNet201 models use ImageNet weights and include a fine-tuning stage.

## Methodology

The project workflow includes:

1. Dataset preparation
2. Data splitting
3. Image preprocessing
4. Image resizing
5. Training data augmentation
6. CNN model development
7. Transfer learning
8. Model fine-tuning
9. Model evaluation
10. Performance comparison

## Evaluation

The models are evaluated using:

* Accuracy
* Precision
* Recall
* F1-score
* Classification report
* Confusion matrix
* Training and validation performance

## Project Files

```text
flower-recognition-deep-learning-transfer-learning/
│
├── README.md
├── notebooks/
├── results/
├── report/
└── requirements.txt
```

## Technologies

Python | PyTorch/TensorFlow | Deep Learning | CNN | Transfer Learning | Computer Vision | Google Colab | NumPy | Pandas | Matplotlib | Scikit-learn

## Academic Context

This project was completed as part of my MSc Artificial Intelligence studies at the University of East London.

## Author

Vadapalli Maneesha